﻿namespace SnowmanAttack
{
    partial class SnowManAttackForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SnowManAttackForm));
            this.CreateSnowman = new System.Windows.Forms.Timer(this.components);
            this.goodSnowman = new System.Windows.Forms.PictureBox();
            this.badSnowman = new System.Windows.Forms.PictureBox();
            this.lblScore = new System.Windows.Forms.Label();
            this.lblHitMiss = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.goodSnowman)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.badSnowman)).BeginInit();
            this.SuspendLayout();
            // 
            // CreateSnowman
            // 
            this.CreateSnowman.Interval = 1000;
            this.CreateSnowman.Tick += new System.EventHandler(this.CreateSnowman_Tick);
            // 
            // goodSnowman
            // 
            this.goodSnowman.Image = ((System.Drawing.Image)(resources.GetObject("goodSnowman.Image")));
            this.goodSnowman.Location = new System.Drawing.Point(333, 53);
            this.goodSnowman.Name = "goodSnowman";
            this.goodSnowman.Size = new System.Drawing.Size(98, 91);
            this.goodSnowman.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.goodSnowman.TabIndex = 1;
            this.goodSnowman.TabStop = false;
            this.goodSnowman.Click += new System.EventHandler(this.goodSnowman_Click);
            // 
            // badSnowman
            // 
            this.badSnowman.Image = ((System.Drawing.Image)(resources.GetObject("badSnowman.Image")));
            this.badSnowman.Location = new System.Drawing.Point(562, 53);
            this.badSnowman.Name = "badSnowman";
            this.badSnowman.Size = new System.Drawing.Size(98, 91);
            this.badSnowman.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.badSnowman.TabIndex = 2;
            this.badSnowman.TabStop = false;
            this.badSnowman.Click += new System.EventHandler(this.badSnowman_Click);
            // 
            // lblScore
            // 
            this.lblScore.AutoSize = true;
            this.lblScore.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblScore.Location = new System.Drawing.Point(880, 13);
            this.lblScore.Name = "lblScore";
            this.lblScore.Size = new System.Drawing.Size(78, 27);
            this.lblScore.TabIndex = 3;
            this.lblScore.Text = "Score: ";
            // 
            // lblHitMiss
            // 
            this.lblHitMiss.AutoSize = true;
            this.lblHitMiss.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHitMiss.Location = new System.Drawing.Point(12, 13);
            this.lblHitMiss.Name = "lblHitMiss";
            this.lblHitMiss.Size = new System.Drawing.Size(65, 27);
            this.lblHitMiss.TabIndex = 5;
            this.lblHitMiss.Text = "Miss!";
            // 
            // SnowManAttackForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1030, 647);
            this.Controls.Add(this.lblHitMiss);
            this.Controls.Add(this.lblScore);
            this.Controls.Add(this.badSnowman);
            this.Controls.Add(this.goodSnowman);
            this.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "SnowManAttackForm";
            this.Text = "Snowman Attack";
            this.Load += new System.EventHandler(this.SnowManAttackForm_Load);
            this.Click += new System.EventHandler(this.Form_Click);
            ((System.ComponentModel.ISupportInitialize)(this.goodSnowman)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.badSnowman)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Timer CreateSnowman;
        private System.Windows.Forms.PictureBox goodSnowman;
        private System.Windows.Forms.PictureBox badSnowman;
        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.Label lblHitMiss;
    }
}

