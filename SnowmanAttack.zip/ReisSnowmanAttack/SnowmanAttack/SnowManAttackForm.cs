﻿/*******************************************************************************************
 * Snowman Attack displays one of two snowmen for 1 second (as it stands right now). It
 * does this by randomly picking a number 1 or 2.  If a 1 is chosen the good snowman will be
 * displayed at a random location.  If a 2 is choses the bad snowman will be displayed at 
 * a random location.  The goal for the user is to click on the bad snowmen only.  If the user
 * clicks on a good snowman the player loses 10 points.  If the user clicks on a bad snowman
 * the player gains 10 points.  If the user just clicks on the background, the player loses 5
 * points.  Each time the user clicks, the score is updated and a message indicating whether he
 * or she hit a good snowman, hit a bad snowman, or missed completely.  
 * ******************************************************************************************/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SnowmanAttack
{
    public partial class SnowManAttackForm : Form
    {
        //Create a Random Number Generator
        Random gen;
        //Score is an instance variable that is known throughout the entire program
        int score;


        public SnowManAttackForm()
        {
            InitializeComponent();
            //Instantiate the gen random number generator
            gen = new Random();
            //Initialize the score
            score = 0;
            
            
            
        }
        /*********************************************************
         * UpdateScore(int pScore)
         * Update the score both internally and on the label
         * If the user clicked on a good snowman, they get 10 points
         * If the user clicked on a bad snowman, they lose 10 points
         * If the user clicked on the background, they lose 5 points
         *********************************************************/
        public void UpdateScore(int pScore)
        {
            score = score + pScore;
            lblScore.Text = "Score: " + score.ToString();

            /*************************************************************
             * UpdateText(string pText)
             * Set the text to indicate whether the user clicked on a 
             * a good snowman, bad snowman or the background
             * ***********************************************************/
        }
         public void UpdateText(string pText)
         {
                lblHitMiss.Text = pText;
         }

        /**********************************************************
         * GenerateSnowmanXPosition()
         * Generate and return a random number between 50 and the
         * width of the form minus 150
         **********************************************************/
         public int GenerateSnowmanXPosition()
        {
                return (gen.Next(50, this.Width - 150));
        }

        /**********************************************************
        * GenerateSnowmanYPosition()
        * Generate a return random number between 50 and the height of the
        * form minus 150
        **********************************************************/
         public int GenerateSnowmanYPosition()
        {
                return (gen.Next(50, this.Height - 50));
        }

        /************************************************************
         * DetermineGoodOrBad()
         * Determines if the good or bad snowman will appear
         * Returns a 1 or 2.  1 means good and bad means 2
         ************************************************************/
        public int DetermineGoodOrBad()
        {
                return (gen.Next(1, 3));
        }

        private void CreateSnowman_Tick(object sender, EventArgs e)
        {
            //Set both snowmen to initially be invisible
            goodSnowman.Visible = false;
            badSnowman.Visible = false;

                //Call the GenerateSnowmanXPosition function and store the result in an int variable called xPos
                int xPos = GenerateSnowmanXPosition();

                //#9 Call the GenerateSnowmanYPosition function and store the result in an int variable called yPos
                int yPos = GenerateSnowmanYPosition();
                //#10 Call the DetermineGoodOrBad() function and store the result in an int variable called goorOrBad.
                int goodOrBad = DetermineGoodOrBad();

            if (goodOrBad == 1)
            {
                goodSnowman.Location = new Point(xPos, yPos);
                goodSnowman.Visible = true;
            }
            else
            {
                badSnowman.Location = new Point(xPos, yPos);
                badSnowman.Visible = true;
            }
               

        }


        private void SnowManAttackForm_Load(object sender, EventArgs e)
        {
            //Start the timer for the snowman created
            CreateSnowman.Start();
        }

        /************************************************************************
          * If the user clicks on the form, call UpdateScore and pass in a 10
          * and call UpdateText and pass in the text that says
          * "KILLED BAD SNOWMAN!
          *************************************************************************/
        private void badSnowman_Click(object sender, EventArgs e)
        {
                //#13 If the user clicks on the badSnowman, call UpdateScore and pass in a 10 and call UpdateText and pass 
                //in the text that says "KILLED BAD SNOWMAN!”.  The code for this is in #13 on the handout
                UpdateScore(10);
                UpdateText("KILLED BAD SNOWMAN");
        }

            /************************************************************************
              * If the user clicks on the form, call UpdateScore and pass in a -10
              * and call UpdateText and pass in the text that says
              * "KILLED GOOD SNOWMAN!
              *************************************************************************/
        private void goodSnowman_Click(object sender, EventArgs e)
        {
                //#14 If the user clicks on the goodSnoman, call UpdateScore and pass in a
                //-10 and call UpdateText and pass 
                //in the text that says "KILLED GOOD SNOWMAN!”.  
                UpdateScore(-10);
                UpdateText("KILLED GOOD SNOWMAN!");
            }

        /************************************************************************
         * If the user clicks on the form, call UpdateScore and pass in a -5
         * and call UpdateText and pass in the text that says
         * "YOU MISSED COMPLETELY!
         *************************************************************************/
        private void Form_Click(object sender, EventArgs e)
        {
                //#15 If the user clicks on the background of the form, 
                //call UpdateScore and pass in a
                //-5 and call UpdateText and pass 
                //in the text that says "YOU MISSED COMPLETELY!”.  
                UpdateScore(-5);
                UpdateText("YOU MISSED COMPLETELY!");

        }
    }
}
