﻿namespace Reis_Math
{
    partial class MathForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MathForm));
            this.txtNum1 = new System.Windows.Forms.TextBox();
            this.txtNum2 = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnSubtract = new System.Windows.Forms.Button();
            this.btnMultiply = new System.Windows.Forms.Button();
            this.txtDisplay = new System.Windows.Forms.RichTextBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.sqrButton = new System.Windows.Forms.Button();
            this.lblTheme1 = new System.Windows.Forms.Label();
            this.lblTheme2 = new System.Windows.Forms.Label();
            this.lblTheme3 = new System.Windows.Forms.Label();
            this.lblTheme4 = new System.Windows.Forms.Label();
            this.btnDivide = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtNum1
            // 
            this.txtNum1.Location = new System.Drawing.Point(49, 52);
            this.txtNum1.Margin = new System.Windows.Forms.Padding(4);
            this.txtNum1.Name = "txtNum1";
            this.txtNum1.Size = new System.Drawing.Size(132, 26);
            this.txtNum1.TabIndex = 0;
            // 
            // txtNum2
            // 
            this.txtNum2.Location = new System.Drawing.Point(49, 98);
            this.txtNum2.Margin = new System.Windows.Forms.Padding(4);
            this.txtNum2.Name = "txtNum2";
            this.txtNum2.Size = new System.Drawing.Size(132, 26);
            this.txtNum2.TabIndex = 1;
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.Location = new System.Drawing.Point(49, 143);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(4);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(100, 27);
            this.btnAdd.TabIndex = 2;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnSubtract
            // 
            this.btnSubtract.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubtract.Location = new System.Drawing.Point(49, 190);
            this.btnSubtract.Margin = new System.Windows.Forms.Padding(4);
            this.btnSubtract.Name = "btnSubtract";
            this.btnSubtract.Size = new System.Drawing.Size(100, 26);
            this.btnSubtract.TabIndex = 3;
            this.btnSubtract.Text = "Subtract";
            this.btnSubtract.UseVisualStyleBackColor = true;
            this.btnSubtract.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnMultiply
            // 
            this.btnMultiply.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMultiply.Location = new System.Drawing.Point(49, 240);
            this.btnMultiply.Margin = new System.Windows.Forms.Padding(4);
            this.btnMultiply.Name = "btnMultiply";
            this.btnMultiply.Size = new System.Drawing.Size(100, 27);
            this.btnMultiply.TabIndex = 4;
            this.btnMultiply.Text = "Multiply";
            this.btnMultiply.UseVisualStyleBackColor = true;
            this.btnMultiply.Click += new System.EventHandler(this.btnMultiply_Click);
            // 
            // txtDisplay
            // 
            this.txtDisplay.BackColor = System.Drawing.Color.Black;
            this.txtDisplay.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDisplay.Cursor = System.Windows.Forms.Cursors.Default;
            this.txtDisplay.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDisplay.ForeColor = System.Drawing.Color.White;
            this.txtDisplay.Location = new System.Drawing.Point(382, 52);
            this.txtDisplay.Margin = new System.Windows.Forms.Padding(4);
            this.txtDisplay.Name = "txtDisplay";
            this.txtDisplay.Size = new System.Drawing.Size(297, 314);
            this.txtDisplay.TabIndex = 5;
            this.txtDisplay.Text = "";
            this.txtDisplay.TextChanged += new System.EventHandler(this.txtDisplay_TextChanged);
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClear.Font = new System.Drawing.Font("Constantia", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnClear.Location = new System.Drawing.Point(579, 378);
            this.btnClear.Margin = new System.Windows.Forms.Padding(4);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(100, 32);
            this.btnClear.TabIndex = 6;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // sqrButton
            // 
            this.sqrButton.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sqrButton.Location = new System.Drawing.Point(49, 340);
            this.sqrButton.Name = "sqrButton";
            this.sqrButton.Size = new System.Drawing.Size(100, 26);
            this.sqrButton.TabIndex = 7;
            this.sqrButton.Text = "Square";
            this.sqrButton.UseVisualStyleBackColor = true;
            this.sqrButton.Click += new System.EventHandler(this.sqrButton_Click);
            // 
            // lblTheme1
            // 
            this.lblTheme1.BackColor = System.Drawing.Color.Black;
            this.lblTheme1.ForeColor = System.Drawing.Color.Black;
            this.lblTheme1.Image = ((System.Drawing.Image)(resources.GetObject("lblTheme1.Image")));
            this.lblTheme1.Location = new System.Drawing.Point(-4, -2);
            this.lblTheme1.Name = "lblTheme1";
            this.lblTheme1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblTheme1.Size = new System.Drawing.Size(531, 26);
            this.lblTheme1.TabIndex = 8;
            // 
            // lblTheme2
            // 
            this.lblTheme2.BackColor = System.Drawing.Color.Black;
            this.lblTheme2.ForeColor = System.Drawing.Color.Black;
            this.lblTheme2.Image = ((System.Drawing.Image)(resources.GetObject("lblTheme2.Image")));
            this.lblTheme2.Location = new System.Drawing.Point(523, -2);
            this.lblTheme2.Name = "lblTheme2";
            this.lblTheme2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblTheme2.Size = new System.Drawing.Size(169, 26);
            this.lblTheme2.TabIndex = 9;
            // 
            // lblTheme3
            // 
            this.lblTheme3.BackColor = System.Drawing.Color.Black;
            this.lblTheme3.ForeColor = System.Drawing.Color.Black;
            this.lblTheme3.Image = ((System.Drawing.Image)(resources.GetObject("lblTheme3.Image")));
            this.lblTheme3.Location = new System.Drawing.Point(-6, 24);
            this.lblTheme3.Name = "lblTheme3";
            this.lblTheme3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblTheme3.Size = new System.Drawing.Size(31, 354);
            this.lblTheme3.TabIndex = 10;
            // 
            // lblTheme4
            // 
            this.lblTheme4.BackColor = System.Drawing.Color.Black;
            this.lblTheme4.ForeColor = System.Drawing.Color.Black;
            this.lblTheme4.Image = ((System.Drawing.Image)(resources.GetObject("lblTheme4.Image")));
            this.lblTheme4.Location = new System.Drawing.Point(1, 378);
            this.lblTheme4.Name = "lblTheme4";
            this.lblTheme4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblTheme4.Size = new System.Drawing.Size(24, 56);
            this.lblTheme4.TabIndex = 11;
            // 
            // btnDivide
            // 
            this.btnDivide.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDivide.Location = new System.Drawing.Point(49, 289);
            this.btnDivide.Margin = new System.Windows.Forms.Padding(4);
            this.btnDivide.Name = "btnDivide";
            this.btnDivide.Size = new System.Drawing.Size(100, 26);
            this.btnDivide.TabIndex = 12;
            this.btnDivide.Text = "Divide";
            this.btnDivide.UseVisualStyleBackColor = true;
            this.btnDivide.Click += new System.EventHandler(this.btnDivide_Click);
            // 
            // MathForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.ClientSize = new System.Drawing.Size(685, 423);
            this.Controls.Add(this.btnDivide);
            this.Controls.Add(this.lblTheme4);
            this.Controls.Add(this.lblTheme3);
            this.Controls.Add(this.lblTheme2);
            this.Controls.Add(this.lblTheme1);
            this.Controls.Add(this.sqrButton);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.txtDisplay);
            this.Controls.Add(this.btnMultiply);
            this.Controls.Add(this.btnSubtract);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.txtNum2);
            this.Controls.Add(this.txtNum1);
            this.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "MathForm";
            this.Text = "Simple Math Calculator";
            this.Load += new System.EventHandler(this.MathForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtNum1;
        private System.Windows.Forms.TextBox txtNum2;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnSubtract;
        private System.Windows.Forms.Button btnMultiply;
        private System.Windows.Forms.RichTextBox txtDisplay;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button sqrButton;
        private System.Windows.Forms.Label lblTheme1;
        private System.Windows.Forms.Label lblTheme2;
        private System.Windows.Forms.Label lblTheme3;
        private System.Windows.Forms.Label lblTheme4;
        private System.Windows.Forms.Button btnDivide;
    }
}

