﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/**********************************
* 
* Project Name: Reis_Math
* Author: Keith Reis
* Purpose: Calculate any number of mathematical problems the user gives the program
* Input: userNum1 and userNum2
* Output: sum 
*
************************************/


namespace Reis_Math
{
    public partial class MathForm : Form
    {
        public MathForm()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Initialize default values for user input
            double userNum1 = 0;
            double userNum2 = 0;

            //Check if numbers have been placed into both text boxes, then begin computation
            if (txtNum1.Text.Length > 0 && txtNum2.Text.Length > 0)
            {
                //Take text from txtBox1 & convert into double
                userNum1 = double.Parse(txtNum1.Text);
                //Take text from txtBox2 & convert into double
                userNum2 = double.Parse(txtNum2.Text);
                //Calculate sum & store it in sum variable
                double sum = userNum1 - userNum2;
                //Display result in rich text box
                txtDisplay.AppendText(userNum1.ToString() + " - " +
                    userNum2.ToString() + " = " + sum.ToString() + "\n");
            }

            //ERROR HANDLING
            if (txtNum1.Text.Length == 0 && txtNum2.Text.Length == 0)
            {
                MessageBox.Show("You must enter a number into BOTH input fields");
            }
            else if (txtNum1.Text.Length == 0)
            {
                MessageBox.Show("You must enter a number into the first input field");
            }
            else if (txtNum2.Text.Length == 0)
            {
                MessageBox.Show("You must enter a number into the second input field");
            }

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            //Initialize default values for user input
            double userNum1 = 0;
            double userNum2 = 0;

            //Check if numbers have been placed into both text boxes, then begin computation
            if (txtNum1.Text.Length > 0 && txtNum2.Text.Length > 0)
            {
                //Take text from txtBox1 & convert into double
                userNum1 = double.Parse(txtNum1.Text);
                //Take text from txtBox2 & convert into double
                userNum2 = double.Parse(txtNum2.Text);
                //Calculate sum & store it in sum variable
                double sum = userNum1 + userNum2;
                //Display result in rich text box
                txtDisplay.AppendText(userNum1.ToString() + " + " +
                    userNum2.ToString() + " = " + sum.ToString() + "\n");
            }

            //ERROR HANDLING
            if (txtNum1.Text.Length == 0 && txtNum2.Text.Length == 0)
            {
                MessageBox.Show("You must enter a number into BOTH input fields");
            }
            else if (txtNum1.Text.Length == 0)
            {
                MessageBox.Show("You must enter a number into the first input field");
            }
            else if (txtNum2.Text.Length == 0)
            {
                MessageBox.Show("You must enter a number into the second input field");
            }

        }

        
        private void btnMultiply_Click(object sender, EventArgs e)
        {
            //Initialize default values for user input
            double userNum1 = 0;
            double userNum2 = 0;

            //Check if numbers have been placed into both text boxes, then begin computation
            if (txtNum1.Text.Length > 0 && txtNum2.Text.Length > 0)
            {
                //Take text from txtBox1 & convert into double
                userNum1 = double.Parse(txtNum1.Text);
                //Take text from txtBox2 & convert into double
                userNum2 = double.Parse(txtNum2.Text);
                //Calculate sum & store it in sum variable
                double sum = userNum1 * userNum2;
                //Display result in rich text box
                txtDisplay.AppendText(userNum1.ToString() + " * " +
                    userNum2.ToString() + " = " + sum.ToString() + "\n");
            }

            //ERROR HANDLING
            if (txtNum1.Text.Length == 0 && txtNum2.Text.Length == 0)
            {
                MessageBox.Show("You must enter a number into BOTH input fields");
            }
            else if (txtNum1.Text.Length == 0)
            {
                MessageBox.Show("You must enter a number into the first input field");
            }
            else if (txtNum2.Text.Length == 0)
            {
                MessageBox.Show("You must enter a number into the second input field");
            }

        }

        private void btnDivide_Click(object sender, EventArgs e)
        {
            //Initialize default values for user input
            double userNum1 = 0;
            double userNum2 = 0;

            //Check if numbers have been placed into both text boxes, then begin computation
            if (txtNum1.Text.Length > 0 && txtNum2.Text.Length > 0)
            {
                //Take text from txtBox1 & convert into double
                userNum1 = double.Parse(txtNum1.Text);
                //Take text from txtBox2 & convert into double
                userNum2 = double.Parse(txtNum2.Text);
                //Calculate sum & store it in sum variable
                double sum = userNum1 / userNum2;
                //Display result in txtDisplay
                txtDisplay.AppendText(userNum1.ToString() + " / " +
                userNum2.ToString() + " = " + sum.ToString() + "\n");
            }

            //ERROR HANDLING
            if (txtNum1.Text.Length == 0 && txtNum2.Text.Length == 0)
            {
                MessageBox.Show("You must enter a number into BOTH input fields");
            }
            else if (txtNum1.Text.Length == 0)
            {
                MessageBox.Show("You must enter a number into the first input field");
            }
            else if (txtNum2.Text.Length == 0)
            {
                MessageBox.Show("You must enter a number into the second input field");
            }
        }

        private void sqrButton_Click(object sender, EventArgs e)
        {
            //Initialize default values for user input
            double userNum1 = 0;
            double userNum2 = 0;

            //Check if numbers have been placed into both text boxes, then begin computation
            if (txtNum1.Text.Length > 0 && txtNum2.Text.Length > 0)
            {
                //Take text from txtBox1 & convert into double
                userNum1 = double.Parse(txtNum1.Text);
                //Take text from txtBox2 & convert into double
                userNum2 = double.Parse(txtNum2.Text);
                //Calculate sum & store it in sum variable
                double sum = userNum1 * userNum1 + userNum2 * userNum2;
                //Display result in txtDisplay
                txtDisplay.AppendText(userNum1.ToString() + "^2 + " +
                userNum2.ToString() + "^2 = " + sum.ToString() + "\n");
            }

            //ERROR HANDLING
            if (txtNum1.Text.Length == 0 && txtNum2.Text.Length == 0)
            {
                MessageBox.Show("You must enter a number into BOTH input fields");
            }
            else if (txtNum1.Text.Length == 0)
            {
                MessageBox.Show("You must enter a number into the first input field");
            }
            else if (txtNum2.Text.Length == 0)
            {
                MessageBox.Show("You must enter a number into the second input field");
            }

        }

        //Clears text from both input boxes & answer display box
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtNum1.Clear();
            txtNum2.Clear();
            txtDisplay.Clear();
        }

        private void MathForm_Load(object sender, EventArgs e)
        {
            //Set the txtDisplay box to readonly so users cannot type text into the box
            txtDisplay.ReadOnly = true;
        }

        private void txtDisplay_TextChanged(object sender, EventArgs e)
        {
            
        }

    }
}
